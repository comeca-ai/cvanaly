# Contribuindo para o CV Analyzer

Obrigado pelo seu interesse em contribuir para o CV Analyzer! Este documento fornece diretrizes para contribuir com o projeto.

## Como Contribuir

1. Faça um Fork do repositório
2. Clone o seu fork: `git clone https://github.com/seu-usuario/cv-analyzer.git`
3. Crie uma branch para sua feature: `git checkout -b feature/nova-funcionalidade`
4. Faça suas alterações
5. Commit suas mudanças: `git commit -m 'Adiciona nova funcionalidade'`
6. Push para a branch: `git push origin feature/nova-funcionalidade`
7. Abra um Pull Request

## Diretrizes de Código

- Siga as convenções de estilo PEP 8 para código Python
- Mantenha o código limpo e bem documentado
- Adicione comentários quando necessário
- Escreva testes para novas funcionalidades

## Relatando Bugs

Se você encontrar um bug, por favor, abra uma issue com as seguintes informações:

- Descrição clara do problema
- Passos para reproduzir
- Comportamento esperado vs. comportamento atual
- Screenshots, se aplicável
- Ambiente (sistema operacional, navegador, etc.)

## Sugerindo Melhorias

Para sugerir melhorias, abra uma issue descrevendo:

- A funcionalidade que você gostaria de ver
- Por que essa funcionalidade seria útil
- Como você imagina que ela funcionaria

## Processo de Pull Request

1. Atualize seu fork com as mudanças mais recentes do repositório original
2. Certifique-se de que seu código segue as diretrizes do projeto
3. Inclua uma descrição clara do que sua PR resolve
4. Vincule a PR a qualquer issue relacionada

Agradecemos sua contribuição para tornar o CV Analyzer melhor!
